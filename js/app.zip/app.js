// js/app.js
import { auth, db } from "./config.js";
import { DataService } from "./services.js";
import * as UI from "./ui.js";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import {
  onSnapshot,
  collection,
  query,
  where,
  getDocs,
  doc,
  getDoc,
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

let state = {
  residents: [],
  sheets: [],
  summaries: [],
  collections: [],
  expenses: [],
  currentSheetId: null,
  currentSheetName: null,
  currentSheetDate: null,
  activeStatusFilter: "all",
  editingResidentId: null,
};

// --- PUBLIC VERIFICATION LOGIC (Phase 6) ---
const urlParams = new URLSearchParams(window.location.search);
let publicReceiptId = urlParams.get('receiptId');

// Amount to Words Function (Indian Numbering System)
function numberToWords(num) {
  const a = [
    "",
    "one ",
    "two ",
    "three ",
    "four ",
    "five ",
    "six ",
    "seven ",
    "eight ",
    "nine ",
    "ten ",
    "eleven ",
    "twelve ",
    "thirteen ",
    "fourteen ",
    "fifteen ",
    "sixteen ",
    "seventeen ",
    "eighteen ",
    "nineteen ",
  ];
  const b = [
    "",
    "",
    "twenty",
    "thirty",
    "forty",
    "fifty",
    "sixty",
    "seventy",
    "eighty",
    "ninety",
  ];

  if ((num = num.toString()).length > 9) return "overflow";
  let n = ("000000000" + num)
    .substr(-9)
    .match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
  if (!n) return "";
  let str = "";
  str +=
    n[1] != 0
      ? (a[Number(n[1])] || b[n[1][0]] + " " + a[n[1][1]]) + "crore "
      : "";
  str +=
    n[2] != 0
      ? (a[Number(n[2])] || b[n[2][0]] + " " + a[n[2][1]]) + "lakh "
      : "";
  str +=
    n[3] != 0
      ? (a[Number(n[3])] || b[n[3][0]] + " " + a[n[3][1]]) + "thousand "
      : "";
  str += n[4] != 0 ? (a[Number(n[4])] || b[n[4][0]]) + "hundred " : "";
  str +=
    n[5] != 0
      ? (str != "" ? "and " : "") +
        (a[Number(n[5])] || b[n[5][0]] + " " + a[n[5][1]])
      : "";
  return str.trim() + " only";
}

async function handlePublicVerification(receiptId) {
    // 1. Force Clean ID (Extra slash ya space hatane ke liye)
    const cleanId = receiptId.replace(/\/$/, "").trim();

    // UI Initial State: Loading dikhao, baaki sab chhupao
    document.getElementById("loading").style.display = "none";
    document.getElementById("auth-container").classList.add("hidden");
    document.getElementById("content-container").classList.add("hidden");
    document.getElementById("verification-view").classList.remove("hidden");
    document.getElementById("verify-loading").classList.remove("hidden");
    document.getElementById("verify-content").classList.add("hidden");
    document.getElementById("verify-error").classList.add("hidden");

    try {
        // 2. Firestore fetch with sanitized ID
        const docRef = doc(db, "maintenance", cleanId);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
            const data = docSnap.data();
            
            // 3. Clean Base URL Logic for QR/Sharing
            const cleanBaseUrl = window.location.origin + window.location.pathname;
            const finalVerificationLink = `${cleanBaseUrl}?receiptId=${cleanId}`;

            // Sheet Name fetch karein
            let sheetName = "Maintenance";
            if (data.sheetId) {
                const sheetSnap = await getDoc(doc(db, "expense_sheets", data.sheetId));
                if (sheetSnap.exists()) sheetName = sheetSnap.data().name;
            }

            // --- A. PREMIUM PDF TEMPLATE POPULATION (For Download) ---
            document.getElementById("p-receipt-no").textContent = data.receiptNo || "-";
            document.getElementById("p-date").textContent = data.date || "-";
            document.getElementById("p-name").textContent = data.ownerName || "-";
            document.getElementById("p-flat").textContent = data.flatNo || "-";
            document.getElementById("p-month").textContent = sheetName;
            document.getElementById("p-main-amount").textContent = UI.formatCurrency(data.amount);
            document.getElementById("p-total-amount").textContent = UI.formatCurrency(data.amount);

            const words = numberToWords(data.amount);
            document.getElementById("p-words").textContent = words.charAt(0).toUpperCase() + words.slice(1);
            document.getElementById("p-hash-bottom").textContent = cleanId;

            // --- B. CARD UI UPDATE (For Screen View) ---
            document.getElementById("v-flat").textContent = data.flatNo || "-";
            document.getElementById("v-name").textContent = data.ownerName || "-";
            document.getElementById("v-amount").textContent = UI.formatCurrency(data.amount);
            document.getElementById("v-date").textContent = data.date || "-";
            document.getElementById("v-hash").textContent = `ID: ${cleanId}`;

            // --- C. QR CODE GENERATION ---
            const qrContainer = document.getElementById('p-qr-code');
            if (qrContainer) {
                qrContainer.innerHTML = ''; 
                setTimeout(() => {
                    new QRCode(qrContainer, {
                        text: finalVerificationLink, 
                        width: 80,
                        height: 80,
                        colorDark : "#1e40af",
                        colorLight : "#ffffff",
                        correctLevel : QRCode.CorrectLevel.H
                    });
                }, 150);
            }

            // Success: Switch visibility from loading to content
            document.getElementById("verify-loading").classList.add("hidden");
            document.getElementById("verify-content").classList.remove("hidden");

        } else {
            console.error("Document not found for ID:", cleanId);
            throw new Error("Record not found");
        }
    } catch (error) {
        console.error("Verification error:", error);
        document.getElementById("verify-loading").classList.add("hidden");
        document.getElementById("verify-error").classList.remove("hidden");
    }
}

// PDF Download Button Logic (Fixed for full capture)
document.getElementById('v-download')?.addEventListener('click', async () => {
    const btn = document.getElementById('v-download');
    const originalText = btn.innerText;
    btn.innerText = "Generating...";
    btn.disabled = true;

    const printArea = document.getElementById('receipt-print-area');
    
    // TRICK: Receipt ko visible karein lekin screen ke bahar taaki QR aur Table render ho sakein
    printArea.style.display = "block";
    printArea.style.position = "absolute";
    printArea.style.left = "-9999px";
    printArea.classList.remove('hidden');

    try {
        // Wait for 200ms taaki QR library render ho jaye
        await new Promise(r => setTimeout(r, 200));

        const canvas = await html2canvas(printArea, { 
            scale: 2,
            useCORS: true,
            backgroundColor: "#ffffff",
            logging: false,
            height: printArea.offsetHeight, // Force capturing the full element height
            windowHeight: printArea.scrollHeight 
        });

        const imgData = canvas.toDataURL('image/png');
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF('p', 'mm', 'a4');
        
        const imgProps = pdf.getImageProperties(imgData);
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
        
        pdf.addImage(imgData, 'PNG', 0, 5, pdfWidth, pdfHeight);
        pdf.save(`Receipt_Flat_${document.getElementById('p-flat').textContent}.pdf`);
    } catch (err) {
        console.error("PDF Error:", err);
        alert("Generation failed. Please try again.");
    } finally {
        // Reset and hide
        printArea.style.display = "";
        printArea.style.position = "";
        printArea.style.left = "";
        printArea.classList.add('hidden');
        btn.innerText = originalText;
        btn.disabled = false;
    }
});

// --- VIEW MANAGEMENT ---
function renderView(viewId) {
    // CRITICAL: Agar publicReceiptId hai, toh views switch karna STRICTLY forbidden hai
    if (new URLSearchParams(window.location.search).get('receiptId')) return;

    ['dashboard-view', 'residents-view', 'detail-view'].forEach(v => {
        const el = document.getElementById(v); 
        if (el) el.classList.toggle('hidden', v !== viewId);
    });
}
function navigateTo(viewId) {
  history.pushState({ viewId }, "", `#${viewId}`);
  renderView(viewId);
}
window.addEventListener("popstate", (e) => {
  const viewId = e.state && e.state.viewId ? e.state.viewId : "dashboard-view";
  renderView(viewId);
});

// --- AUTH ---
onAuthStateChanged(auth, user => {
    const currentId = new URLSearchParams(window.location.search).get('receiptId');

    if (currentId) {
        handlePublicVerification(currentId);
        return; // Yahan se exit, aage kuch mat karo
    }

    document.getElementById('loading').style.display = 'none';
    if (user) {
        // Admin logic hamesha tabhi chalega jab receiptId NAHI ho
        document.getElementById('auth-container').classList.add('hidden');
        document.getElementById('content-container').classList.remove('hidden');
        renderView('dashboard-view');
        initGlobal();
    } else {
        // Login screen dikhao
        document.getElementById('auth-container').classList.remove('hidden');
        document.getElementById('content-container').classList.add('hidden');
    }
});

function initGlobal() {
  onSnapshot(collection(db, "expense_sheets"), (s) => {
    state.sheets = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    UI.renderDashboardSheets(state.sheets);
  });
  onSnapshot(collection(db, "residents"), (s) => {
    state.residents = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    UI.renderResidentsTable(state.residents);
    populateFlatDropdown();
    if (state.currentSheetId)
      UI.renderStatus(
        state.residents,
        state.collections,
        state.activeStatusFilter,
      );
  });
  onSnapshot(collection(db, "monthly_summary"), (s) => {
    state.summaries = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    UI.renderMonthlySummaries(state.summaries);
  });
}

function initSheet(id) {
  onSnapshot(
    query(collection(db, "expenses"), where("sheetId", "==", id)),
    (s) => {
      state.expenses = s.docs.map((d) => ({ id: d.id, ...d.data() }));
      UI.renderExpenses(state.expenses);
      updateSheetSummary();
    },
  );
  onSnapshot(
    query(collection(db, "maintenance"), where("sheetId", "==", id)),
    (s) => {
      state.collections = s.docs.map((d) => ({ id: d.id, ...d.data() }));
      UI.renderCollections(state.collections);
      UI.renderStatus(
        state.residents,
        state.collections,
        state.activeStatusFilter,
      );
      updateSheetSummary();
    },
  );
}

// --- FINANCIALS ---
async function updateSheetSummary() {
  const opening = await calculateOpening();
  const colTotal = state.collections.reduce((a, b) => a + b.amount, 0);
  const expTotal = state.expenses.reduce((a, b) => a + b.amount, 0);
  document.getElementById("opening-balance").textContent =
    UI.formatCurrency(opening);
  document.getElementById("total-collected").textContent =
    UI.formatCurrency(colTotal);
  document.getElementById("total-expenses").textContent =
    UI.formatCurrency(expTotal);
  document.getElementById("closing-balance").textContent = UI.formatCurrency(
    opening + colTotal - expTotal,
  );
}

async function calculateOpening() {
  const prev = state.sheets.filter(
    (s) =>
      s.status === "active" && s.createdAt.toMillis() < state.currentSheetDate,
  );
  if (prev.length === 0) return 0;
  const ids = prev.map((s) => s.id);
  const [cSnap, eSnap] = await Promise.all([
    getDocs(query(collection(db, "maintenance"), where("sheetId", "in", ids))),
    getDocs(query(collection(db, "expenses"), where("sheetId", "in", ids))),
  ]);
  let t = 0;
  cSnap.forEach((d) => (t += d.data().amount));
  eSnap.forEach((d) => (t -= d.data().amount));
  return t;
}

function populateFlatDropdown() {
  const sel = document.getElementById("m-flat");
  if (!sel) return;
  sel.innerHTML = '<option value="">Select Flat</option>';
  state.residents
    .sort((a, b) => a.flatNo.localeCompare(b.flatNo))
    .forEach((r) => {
      const opt = document.createElement("option");
      opt.value = r.flatNo;
      opt.textContent = `${r.flatNo} - ${r.ownerName}`;
      sel.appendChild(opt);
    });
}

// --- MASTER CLICK HANDLER ---
document.addEventListener("click", async (e) => {
  const t = e.target;
  if (
    t.closest("#back-to-dashboard-from-detail") ||
    t.closest("#back-to-dashboard-from-residents")
  ) {
    history.back();
    return;
  }

  if (t.closest("#theme-toggle")) {
    const isDark = document.documentElement.classList.toggle("dark");
    localStorage.theme = isDark ? "dark" : "light";
    return;
  }

  const sc = t.closest(".sheet-card");
  if (sc && !t.closest(".delete-sheet-btn")) {
    state.currentSheetId = sc.dataset.id;
    state.currentSheetName = sc.dataset.name;
    state.currentSheetDate = parseInt(sc.dataset.date);
    navigateTo("detail-view");
    document.getElementById("header-title").textContent =
      `Sheet: ${sc.dataset.name}`;
    initSheet(sc.dataset.id);
    UI.switchTab("status");
    return;
  }

  if (t.dataset.tab) {
    UI.switchTab(t.dataset.tab);
    return;
  }
  if (t.id === "manage-residents-btn") {
    navigateTo("residents-view");
    return;
  }
  if (t.id === "open-sheet-recycle-bin-modal") {
    UI.createModal("r-bin", "Bin History", `<div id="r-bin-content"></div>`);
    UI.renderRecycleBin(state.sheets);
    return;
  }

  // --- DELETES ---
  if (t.closest(".delete-collection-btn")) {
    if (confirm("Delete Log?")) {
      await DataService.deleteCollection(
        t.closest(".delete-collection-btn").dataset.id,
      );
      UI.showToast("Log Removed: Payment entry successfully deleted.");
    }
  }
  if (t.closest(".delete-expense-btn")) {
    if (confirm("Delete Log?")) {
      await DataService.deleteExpense(
        t.closest(".delete-expense-btn").dataset.id,
      );
      UI.showToast("Log Removed: Expense entry successfully deleted.");
    }
  }

  // --- WHATSAPP RECEIPT SHARING ---
  if (t.closest(".share-receipt-btn")) {
    const btn = t.closest(".share-receipt-btn");
    const id = btn.dataset.id;
    const name = btn.dataset.name;
    const flat = btn.dataset.flat;
    const amount = UI.formatCurrency(btn.dataset.amount);
    const cleanUrl = window.location.origin + window.location.pathname;
    const verificationLink = `${cleanUrl}?receiptId=${id}`;
    const message = `*Dinkar Elite Maintenance Receipt*%0A%0AHello ${name} (Flat ${flat}), your maintenance payment of ${amount} has been successfully recorded.%0A%0AYou can view and download your digital receipt here:%0A${verificationLink}%0A%0A_This is an automated message from Society Finance Manager._`;
    window.open(`https://wa.me/?text=${message}`, "_blank");
    return;
  }

  if (t.closest(".delete-sheet-btn"))
    if (confirm("Move to Bin?"))
      await DataService.updateSheet(t.closest(".delete-sheet-btn").dataset.id, {
        status: "deleted",
      });
  if (t.closest(".restore-sheet-btn")) {
    await DataService.updateSheet(t.closest(".restore-sheet-btn").dataset.id, {
      status: "active",
    });
    UI.renderRecycleBin(state.sheets);
    UI.showToast("Sheet Restored: Data is back on the Dashboard.");
  }
  if (t.closest(".delete-resident-btn")) {
    if (confirm("Delete Resident?")) {
      await DataService.deleteResident(
        t.closest(".delete-resident-btn").dataset.id,
      );
      UI.showToast("Resident Removed: Member deleted from database.");
    }
  }
  if (t.closest(".delete-summary-btn"))
    if (confirm("Delete Summary?"))
      await DataService.deleteSummary(
        t.closest(".delete-summary-btn").dataset.id,
      );

  if (t.closest(".edit-resident-btn")) {
    const r = state.residents.find(
      (x) => x.id === t.closest(".edit-resident-btn").dataset.id,
    );
    if (r) {
      state.editingResidentId = r.id;
      document.getElementById("r-flat").value = r.flatNo;
      document.getElementById("r-name").value = r.ownerName;
      document.getElementById("r-amount").value = r.maintAmount;
      document.getElementById("resident-submit-btn").textContent = "Update";
      document.getElementById("cancel-edit-btn").classList.remove("hidden");
    }
  }
  if (t.id === "cancel-edit-btn") {
    state.editingResidentId = null;
    document.getElementById("resident-form").reset();
    t.classList.add("hidden");
    document.getElementById("resident-submit-btn").textContent = "Add";
  }

  if (t.closest(".edit-summary-btn")) {
    const s = state.summaries.find(
      (x) => x.id === t.closest(".edit-summary-btn").dataset.id,
    );
    const m = UI.createModal(
      "es",
      "Edit Summary",
      `<form id="f-sum"><input id="en" value="${s.monthName}" required class="w-full border p-2 mb-2 rounded dark:bg-slate-700 dark:text-white"><input id="ec" type="number" value="${s.totalCollection}" required class="w-full border p-2 mb-2 rounded dark:bg-slate-700 dark:text-white"><input id="ex" type="number" value="${s.totalExpense}" required class="w-full border p-2 mb-4 rounded dark:bg-slate-700 dark:text-white"><button type="submit" class="bg-blue-600 text-white w-full py-2 rounded font-bold">UPDATE</button></form>`,
    );
    m.querySelector("form").onsubmit = async (ev) => {
      ev.preventDefault();
      await DataService.updateSummary(s.id, {
        monthName: document.getElementById("en").value,
        totalCollection: parseFloat(document.getElementById("ec").value),
        totalExpense: parseFloat(document.getElementById("ex").value),
      });
      m.remove();
    };
  }

  if (t.id === "export-excel-btn")
    UI.exportToExcel(
      state.currentSheetName,
      state.residents,
      state.collections,
      state.expenses,
    );
  if (t.id === "export-pdf-btn") UI.exportToPDF(state.currentSheetName);
  if (t.id === "export-image-btn") UI.exportToImage(state.currentSheetName);

  if (t.dataset.filter) {
    document
      .querySelectorAll("#status-filters button")
      .forEach(
        (b) =>
          (b.className =
            b.dataset.filter === t.dataset.filter
              ? "bg-blue-500 text-white px-3 py-1 text-xs rounded"
              : "bg-gray-200 dark:bg-slate-700 px-3 py-1 text-xs rounded"),
      );
    UI.renderStatus(state.residents, state.collections, t.dataset.filter);
  }

  if (t.id === "open-create-sheet-modal") {
    const m = UI.createModal(
      "cs",
      "New Sheet",
      `<form id="f"><input id="sn" required placeholder="e.g. Feb 2026" class="w-full border p-2 mb-4 dark:bg-slate-700 rounded dark:text-white"><button type="submit" class="bg-blue-600 text-white w-full py-2 rounded font-bold">CREATE</button></form>`,
    );
    m.querySelector("form").onsubmit = async (ev) => {
      ev.preventDefault();
      await DataService.addSheet({
        name: document.getElementById("sn").value,
        createdAt: new Date(),
        status: "active",
      });
      m.remove();
    };
  }

  if (t.id === "open-add-month-modal") {
    const m = UI.createModal(
      "as",
      "New Summary",
      `<form id="f"><input id="n" placeholder="Month" required class="w-full border p-2 mb-2 dark:bg-slate-700 rounded dark:text-white"><input id="c" type="number" placeholder="Collection" required class="w-full border p-2 mb-2 dark:bg-slate-700 rounded dark:text-white"><input id="x" type="number" placeholder="Expense" required class="w-full border p-2 mb-4 dark:bg-slate-700 rounded dark:text-white"><button type="submit" class="bg-blue-600 text-white w-full py-2 rounded font-bold">SAVE</button></form>`,
    );
    m.querySelector("form").onsubmit = async (ev) => {
      ev.preventDefault();
      await DataService.addSummary({
        monthName: document.getElementById("n").value,
        totalCollection: parseFloat(document.getElementById("c").value),
        totalExpense: parseFloat(document.getElementById("x").value),
        createdAt: new Date(),
      });
      m.remove();
    };
  }

  if (t.id === "logoutButton") signOut(auth);
  if (t.matches("[data-close]")) {
    const mod = t.closest(".fixed");
    if (mod) mod.remove();
  }
});

// --- FORM HANDLING ---
document
  .getElementById("resident-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const d = {
      flatNo: document.getElementById("r-flat").value,
      ownerName: document.getElementById("r-name").value,
      maintAmount: parseFloat(document.getElementById("r-amount").value),
      status: document.getElementById("r-status").value,
    };
    if (state.editingResidentId) {
      await DataService.updateResident(state.editingResidentId, d);
      state.editingResidentId = null;
      document.getElementById("resident-submit-btn").textContent = "Add";
      document.getElementById("cancel-edit-btn").classList.add("hidden");
    } else await DataService.addResident(d);
    e.target.reset();
    UI.showToast("Success");
  });

document.getElementById("m-flat")?.addEventListener("change", (e) => {
  const res = state.residents.find((r) => r.flatNo === e.target.value);
  if (res) {
    document.getElementById("m-name").value = res.ownerName;
    document.getElementById("m-amount").value = res.maintAmount;
  }
});

document
  .getElementById("maintenance-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const flatSelected = document
      .getElementById("m-flat")
      .value.toString()
      .trim();
    const existing = state.collections.find(
      (c) => c.flatNo.toString().trim() === flatSelected,
    );
    if (existing) {
      UI.showToast(
        `Log Already Exists: Flat ${flatSelected} is already paid!`,
        true,
      );
      return;
    }
    const dateObj = new Date();
    const year = dateObj.getFullYear();
    const serial = (state.collections.length + 1).toString().padStart(2, "0");
    const receiptNo = `DE/${year}/${state.currentSheetName}/${serial}`;

    try {
      await DataService.addCollection({
        date: document.getElementById("m-date").value,
        flatNo: flatSelected,
        ownerName: document.getElementById("m-name").value,
        amount: parseFloat(document.getElementById("m-amount").value),
        mode: document.getElementById("m-mode").value,
        sheetId: state.currentSheetId,
        receiptNo: receiptNo,
        generatedAt: dateObj,
      });
      e.target.reset();
      UI.showToast(`Log Added: Receipt ${receiptNo} generated.`);
    } catch (err) {
      console.error("Save failed:", err);
      UI.showToast("Error saving payment.", true);
    }
  });

document
  .getElementById("expense-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();
    await DataService.addExpense({
      date: document.getElementById("e-date").value,
      amount: parseFloat(document.getElementById("e-amount").value),
      description: document.getElementById("e-desc").value,
      sheetId: state.currentSheetId,
    });
    e.target.reset();
    UI.showToast("Log Added: Expense successfully saved.");
  });

document.getElementById("loginForm")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    await signInWithEmailAndPassword(
      auth,
      document.getElementById("loginEmail").value,
      document.getElementById("loginPassword").value,
    );
  } catch (err) {
    document.getElementById("authError").textContent = "Login Failed";
  }
});

// --- PWA LOGIC ---
let deferredPrompt;
const installBtn = document.getElementById("install-btn");

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredPrompt = e;
  installBtn.classList.remove("hidden");
  console.log("PWA: Ready to install");
});

installBtn?.addEventListener("click", async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  console.log(`User response: ${outcome}`);
  deferredPrompt = null;
  installBtn.classList.add("hidden");
});

window.addEventListener("appinstalled", () => {
  console.log("PWA: App Installed Successfully");
  installBtn.classList.add("hidden");
});
